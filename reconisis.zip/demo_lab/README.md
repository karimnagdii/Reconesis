# Reconesis Demo Lab

This directory contains a pre-configured Docker network environment designed specifically to test and demonstrate the capabilities of **Reconesis** safely, without scanning live university networks.

## Architecture

The lab creates an isolated Docker bridge network (`172.20.0.0/24`) containing four distinct targets:

| Container Name | IP Address | Simulated Identity | Exposed Services |
| :--- | :--- | :--- | :--- |
| `demo_db_server` | `172.20.0.10` | Database Server | PostgreSQL (5432) |
| `demo_mail_server` | `172.20.0.11` | Mail Server | SMTP (25) |
| `demo_web_server` | `172.20.0.12` | Web Server | HTTP (80) |
| `demo_generic_host` | `172.20.0.13` | Standard Linux Host | SSH (22) |

---

## 🚀 How to Run the Demo

### 1. Start the Lab
Navigate to this directory and start the containers in detached mode:

```bash
cd demo_lab
docker-compose up -d
```
*(Note: It may take a minute the first time as Docker downloads the necessary images).*

### 2. Verify the Lab is Running
Ensure all 4 containers are up:
```bash
docker ps
```

### 3. Run Reconesis
From the root directory of your project, run Reconesis and point it at the lab's dedicated subnet:

```bash
python main.py
# When prompted for the target, enter: 172.20.0.0/24
```

### 4. Stop the Lab
When the demo is finished, clean up the environment:
```bash
docker-compose down
```

## What to Expect in the Demo
When you point Reconesis at `172.20.0.0/24`:
1. **Scout Mode** will instantly sweep the `/24` subnet and discover the 4 live containers.
2. The agent will run a port scan against these 4 IP addresses.
3. Your `CriticalityAssessor` logic will correctly flag `172.20.0.10` as a **Database Server** (due to port 5432) and flag `172.20.0.11` as a **Mail Server** (due to port 25).
4. **Hunter Mode** will execute targeted deeper scans specifically against the DB and Mail server.
5. A final `scan_report.md` will be generated highlighting the critical infrastructure detected.
