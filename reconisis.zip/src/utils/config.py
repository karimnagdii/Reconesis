
import os

class Config:
    # LLM Settings
    GROQ_API_URL = os.getenv("GROQ_API_URL", "https://api.groq.com/openai/v1/chat/completions")
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
    
    # Scanning Settings
    DEFAULT_TIMEOUT = 300  # 5 minutes per scan
    MAX_DEPTH = 3
    
    # Criticality Thresholds
    CRITICAL_PORTS = {22, 23, 80, 443, 3306, 5432, 1433, 3389, 5900, 21, 25, 53}
    CRITICAL_KEYWORDS = ["ssh", "http", "https", "mysql", "postgresql", "mssql", "rdp", "vnc", "ftp", "smtp", "domain"]
