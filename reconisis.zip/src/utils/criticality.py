
from src.utils.config import Config

class CriticalityAssessor:
    def __init__(self):
        self.critical_ports = Config.CRITICAL_PORTS
        self.critical_keywords = Config.CRITICAL_KEYWORDS

    def assess(self, toon_host: dict) -> dict:
        """
        Determines if a host is CRITICAL and identifies its type (Router, Firewall, Mail, DB).
        Returns a dict with 'level' and 'type'.
        """
        score = 0
        asset_type = "Unknown"
        reasons = []
        
        ports = toon_host.get("ports", [])
        port_numbers = {p.get("port") for p in ports}
        services = {p.get("service", "").lower() for p in ports}
        products = {p.get("product", "").lower() for p in ports}
        os_name = toon_host.get("os", {}).get("name", "").lower()

        # Definitions for Critical Assets
        chk_db = {1433, 3306, 5432, 1521, 27017, 6379}
        chk_mail = {25, 110, 143, 465, 587, 993, 995}
        chk_router = {179} # BGP is a strong indicator
        
        # 1. Database Servers
        if port_numbers & chk_db or any(k in s for s in services for k in ["mysql", "postgresql", "oracle", "mongo", "redis"]):
            score += 3
            asset_type = "Database Server"
            reasons.append("Database ports/services detected")

        # 2. Mail Servers
        elif port_numbers & chk_mail or any(k in s for s in services for k in ["smtp", "pop3", "imap", "postfix", "exim"]):
            score += 3
            asset_type = "Mail Server"
            reasons.append("Mail ports/services detected")

        # 3. Firewalls (Harder to detect purely by port, looking for clues)
        elif "fortinet" in os_name or "paloalto" in os_name or "checkpoint" in os_name or "cisco-asa" in os_name:
            score += 3
            asset_type = "Firewall"
            reasons.append("Firewall OS fingerprint detected")
        
        # 4. Routers
        elif (port_numbers & chk_router) or "cisco ios" in os_name or "routeros" in os_name:
            score += 3
            asset_type = "Router"
            reasons.append("Router indicators detected")

        # Fallback for generic high-value
        elif 22 in port_numbers and (80 in port_numbers or 443 in port_numbers):
             score += 1
             if asset_type == "Unknown": asset_type = "Web Server/Admin Console"

        # Determine Level
        level = "LOW"
        if score >= 3:
            level = "CRITICAL"
        elif score >= 1:
            level = "HIGH"
        
        return {
            "level": level,
            "type": asset_type,
            "reasons": reasons
        }
