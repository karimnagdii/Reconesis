
import subprocess
import logging
from typing import Optional

class NmapExecutor:
    def __init__(self):
        self.logger = logging.getLogger("NmapExecutor")

    def execute(self, command: str) -> Optional[str]:
        """
        Executes an Nmap command and returns the XML output.
        Arguments:
            command (str): The full Nmap command line string.
        Returns:
            str: The raw XML output if successful, None otherwise.
        """
        self.logger.info(f"Executing: {command}")
        try:
            # Ensure output is in XML format if not already specified
            if "-oX -" not in command:
                command += " -oX -"
            
            # Use shell=True for Windows compatibility with complex commands
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                check=False  # Don't raise exception on non-zero exit, handle it manually
            )
            
            if result.returncode != 0:
                self.logger.warning(f"Nmap returned non-zero exit code: {result.returncode}")
                # Sometimes nmap returns data even with errors, so we log stderr but continue
                self.logger.warning(f"Stderr: {result.stderr}")
            
            if not result.stdout.strip():
                self.logger.error("Nmap produced no output.")
                return None
                
            return result.stdout
            
        except Exception as e:
            self.logger.error(f"Execution failed: {e}")
            return None
