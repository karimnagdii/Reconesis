
import logging
import json
import time # Import time module
from src.core.toon import TOONParser
from src.core.executor import NmapExecutor
from src.core.agent import GroqAgent
from src.utils.criticality import CriticalityAssessor
from src.utils.config import Config

class ReconesisEngine:
    def __init__(self):
        self.logger = logging.getLogger("ReconesisEngine")
        self.parser = TOONParser()
        self.executor = NmapExecutor()
        self.agent = GroqAgent()
        self.assessor = CriticalityAssessor()
        self.scan_history = []

    def start_scan(self, target: str):
        self.logger.info(f"Starting Reconesis on target: {target}")
        
        # -------------------------------------------------------------
        # PHASE 1: DISCOVERY (Scout Mode)
        # -------------------------------------------------------------
        self.logger.info("PHASE 1: SCOUT MODE - Initial Discovery")
        
        # Ask Agent for Discovery Command
        discovery_cmd = self.agent.generate_strategy({
            "phase": "discovery",
            "target_scope": target
        })
        self.logger.info(f"Agent generated command: {discovery_cmd}")
        
        raw_xml = self.executor.execute(discovery_cmd)
        if not raw_xml: 
            return

        toon_hosts = self.parser.parse(raw_xml)
        if not toon_hosts:
             self.logger.info("No live hosts found.")
             return

        live_ips = [h['target'] for h in toon_hosts]
        self.logger.info(f"Discovered Hosts: {live_ips}")

        # -------------------------------------------------------------
        # PHASE 2: ASSESSMENT (Scout Mode -> Identify Asset Types)
        # -------------------------------------------------------------
        self.logger.info("PHASE 2: SCOUT MODE - Asset Classification")
        
        # Ask Agent for Port Scan Command on discovered hosts
        port_scan_cmd = self.agent.generate_strategy({
            "phase": "port_scan",
            "live_hosts": live_ips
        })
        self.logger.info(f"Agent generated command: {port_scan_cmd}")
        
        raw_xml_detailed = self.executor.execute(port_scan_cmd)
        if not raw_xml_detailed:
            return

        detailed_hosts = self.parser.parse(raw_xml_detailed)

        # Apply Criticality Logic (Python-side logic is faster/reliable for classification than LLM parsing per host)
        critical_targets = []
        for host in detailed_hosts:
            assessment = self.assessor.assess(host)
            host['criticality'] = assessment['level']
            host['type'] = assessment['type']
            host['metrics'] = assessment['reasons']
            
            self.logger.info(f"Host {host['target']} -> {assessment['type']} ({assessment['level']})")
            
            if assessment['level'] in ["CRITICAL", "HIGH"]:
                critical_targets.append({"ip": host['target'], "type": assessment['type']})

        # -------------------------------------------------------------
        # PHASE 3: HUNTER (Deep Scan on Criticals)
        # -------------------------------------------------------------
        if critical_targets:
            self.logger.info(f"PHASE 3: HUNTER MODE - Deep Investigation on {len(critical_targets)} Critical Assets")
            
            hunter_cmd = self.agent.generate_strategy({
                "phase": "hunter",
                "critical_targets": critical_targets
            })
            self.logger.info(f"Agent generated command: {hunter_cmd}")
            
            # Execute Hunter Scan (we might not parse this deeply in this v1, just gather data)
            hunter_xml = self.executor.execute(hunter_cmd)
            # Optionally update detailed_hosts with new info if needed, 
            # but for now we have enough for the report.

        # -------------------------------------------------------------
        # PHASE 4: REPORTING
        # -------------------------------------------------------------
        self.logger.info("PHASE 4: Final Analysis")
        report = self.agent.analyze_results(detailed_hosts)
        
        print("\n=== FINAL REPORT ===\n")
        print(report)
        
        # Save results
        with open("scan_results.json", "w") as f:
            json.dump(detailed_hosts, f, indent=2)
        
        with open("scan_report.md", "w") as f:
            f.write(report)

        self.logger.info("Reconesis Task Completed.")
