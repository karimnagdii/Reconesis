
import requests
import json
import logging
from src.utils.config import Config

class GroqAgent:
    def __init__(self):
        self.logger = logging.getLogger("GroqAgent")
        self.api_url = Config.GROQ_API_URL
        self.api_key = Config.GROQ_API_KEY
        self.model = Config.GROQ_MODEL

    def generate_strategy(self, context_data: dict) -> str:
        """
        Generates the next Nmap command based on the system state (Scout vs Hunter).
        """
        phase = context_data.get("phase", "discovery")
        target_scope = context_data.get("target_scope", "unknown")
        
        # System Prompt 1: Scout Mode (Initial Scans)
        scout_prompt = (
                ```python
            "SYSTEM: You are the 'Scout' module of Reconesis, an automated network reconnaissance engine. "
            "Your objective is broad network mapping and asset discovery. "
            "Focus on speed, stealth, and identifying live hosts and common services. "
            "Use efficient scanning techniques like SYN stealth scans (-sS), host discovery (-sn), and limiting port ranges (--top-ports). "
            "Avoid heavy scripts or intrusive version detection at this stage."
```
        )

        # System Prompt 2: Hunter Mode (Critical Asset Analysis)
        hunter_prompt = (
            "SYSTEM: You are the 'Hunter' module of Reconesis. "
            "Your goal is to deeply investigate specific critical targets to find vulnerabilities. "
            "Use version detection (-sV), OS fingerprinting (-O), and vulnerability scripts (--script vuln). "
            "Target specific ports if known."
        )

        user_prompt = ""
        current_system_prompt = ""

        if phase == "discovery":
            current_system_prompt = scout_prompt
            user_prompt = (
                f"Current Task: Initial Discovery for subnetwork {target_scope}. "
                "Goal: Find live hosts. "
                "Output: Provide ONLY the correct Nmap command."
            )
        
        elif phase == "port_scan":
            current_system_prompt = scout_prompt
            live_hosts = context_data.get("live_hosts", [])
            user_prompt = (
                f"Current Task: Detailed Port Scan. "
                f"Targets: {', '.join(live_hosts)}. "
                "Goal: Identify open ports and services to classify assets. "
                "Output: Provide ONLY the correct Nmap command."
            )

        elif phase == "hunter":
            current_system_prompt = hunter_prompt
            critical_targets = context_data.get("critical_targets", [])
            # critical_targets is a list of dicts: {'ip': '...', 'type': 'Database', ...}
            
            details = "\n".join([f"- {t['ip']} ({t['type']})" for t in critical_targets])
            user_prompt = (
                f"Current Task: Deep Investigation on Critical Assets.\n"
                f"Targets Identified:\n{details}\n"
                "Goal: Verify services and check for vulnerabilities on these specific targets. "
                "Output: Provide ONLY the correct Nmap command."
            )

        full_prompt = f"{current_system_prompt}\n\nUSER: {user_prompt}\n\nASSISTANT:"
        return self._query_groq(full_prompt)

    def analyze_results(self, toon_data: list) -> str:
        """
        Analyzes the final TOON data to produce a summary report.
        """
        prompt = self._build_analysis_prompt(toon_data)
        return self._query_groq(prompt)

    def _query_groq(self, prompt: str) -> str:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "stream": False
        }
        try:
            response = requests.post(self.api_url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"].strip().replace("`", "") # Clean code blocks if LLM adds them
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Groq API error: {e}")
            if hasattr(e, 'response') and e.response is not None:
                self.logger.error(f"Response body: {e.response.text}")
            return ""

    def _build_analysis_prompt(self, toon_data: list) -> str:
        return (
            "SYSTEM: You are a Senior Cybersecurity Analyst. "
            "Review the following Reconesis Scan Data (TOON format) and write a Final Report. "
            "Focus on the detected Critical Assets (Routers, Firewalls, Mail, DB) and potential risks.\n\n"
            f"DATA:\n{json.dumps(toon_data, indent=2)}"
        )
